from Tkinter import *
import  serial



#ser = serial.Serial('/dev/ttyACM0',9600)



def sound_play():
	import pygame
	pygame.mixer.init()
	pygame.mixer.music.load("sirenpolice.wav")
	pygame.mixer.music.play()
	while pygame.mixer.music.get_busy() == True:
		continue
	
	
def alert_msg() :
	while 1  :
		alert=ser.readline()
		if alert > 0 :
			print("__security is breched_alert the system__")
			sound_play()
			sec_frame()
			
		else :
			print("__system is secured__")	
	
	
def opt_last() :
	opt_final=opt
	return opt_final

# buttion option functions
def msg_fan():
	opt=0
	print("fan")
	ser.write('A')
	return opt
	
def msg_light():
	opt=1
	print("lights")
	ser.write('B')
	return opt
def msg_ac():
	opt=2
	print("ac")
	ser.write('C')
	return opt
	
def msg_door():
	opt=3
	print("door_lock")
	ser.write('D')
	return opt			
	
def quit():
	print("shuting Down the System...")	
	import sys; sys.exit()
	
def Stringvar():
	var.set("Alert the system")

def sec_frame():
	
	label = Label(top, text="__SECURITY IS BREACHED__")
	label.grid(row=0,column=0)
	button = Button(top, text="OK", command=lambda: top.destroy())
	button.grid(row=2,column=0)
	
top = Tk()
Toplevel(top)
top.title("INSTITUTE AUTOMATION SYSTEM")


var = StringVar()




frame = Frame(top)
frame.grid(row=1,column=0)
label34=Label(top,text="Welcome to INSTITUTE AUTOMATION SYSTEM",bg='green',font=('arial',10,'bold'),bd=10,relief="raised", anchor='center')
label34.grid(row=0,column=0)

label1=Label(frame,text="Please Press to turn ON/OFF the FAN ")
label1.grid(row=0,column=0)

label2=Label(frame,text="Please Press to turn ON/OFF the LIGHTS ")
label2.grid(row=1,column=0)

label3=Label(frame,text="Please Press to turn ON/OFF the AC ")
label3.grid(row=2,column=0)

label4=Label(frame,text=" Please Press to turn ON/OFF the DOOR LOCK")
label4.grid(row=3,column=0)

frame1= Frame(top)
frame1.grid(row=1,column=1)

# button configuration
#alert=ser.readline()
#print(alert)

fanbutton = Button(frame1, text="FAN", fg="black", command =msg_fan)
fanbutton.grid(row=0,column=1)




lightbutton = Button(frame1, text="LIGHTS", fg="black", command =msg_light)
lightbutton.grid(row=1,column=1)



acbutton = Button(frame1, text="AC", fg="black", command =msg_ac)
acbutton.grid(row=2,column=1)



doorbutton = Button(frame1, text="LOCK", fg="black", command =msg_door)
doorbutton.grid(row=3,column=1)











bottomframe = Frame(top)
bottomframe.grid(row=3,column=0)




secbutton = Button(bottomframe, text="SECURE_SYSTEM", fg="black",command=alert_msg, relief= RAISED)
secbutton.grid(row=0,column=0)

quitbutton = Button(bottomframe, text="QUIT", fg="black",command=quit, relief= RAISED)
quitbutton.grid(row=0,column=1)



# Code to add widgets will go here...
top.mainloop()

